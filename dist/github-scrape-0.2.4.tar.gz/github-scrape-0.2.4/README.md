# Github Scrape

This version scrapes github page for a specified user 
displays a report on the user 

The report contains:
1. Number of followers
2. Number of users being followed
3. Nmber of people following but not following back 
4. Opposite of '3.'
